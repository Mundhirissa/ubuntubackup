package com.Invetoryitem.Invetory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvetoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvetoryApplication.class, args);
	}

}
